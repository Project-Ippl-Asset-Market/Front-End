import React from "react";

function Home() {
  return <div>Selamat datang di halaman utama!</div>;
}

export default Home;
